# TLB TOUR

Free Fire tournament Android app project. Upload this ZIP to the existing GitHub repository and run the Extract TLB TOUR Project workflow.

Includes Firebase Auth/Firestore/Storage and ML Kit OCR dependencies, plus Firestore/Storage security-rule files.
