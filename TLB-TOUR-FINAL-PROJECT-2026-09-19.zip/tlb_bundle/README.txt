TLB TOUR - TWO APP PROJECT BUNDLE

1) TLB-TOUR-PLAYER = Player APK project. This is the existing TLB TOUR player app with the current dark blue/neon color theme, logo, tournaments, wallet, deposit, withdraw, profile, referral, results, point table, leaderboard, notifications and admin-related backend data features.

2) TLB-TOUR-ADMIN = Separate Admin APK project. It uses the same Firebase project/data and has its own Admin Login, dashboard, tournament management, deposit/withdraw approval, users, results, point table, leaderboard and notifications.

Admin login only works for a Firebase user whose users/{uid}.role is "admin".

The same Firebase project configuration is included. For a separately registered Firebase Android app, add its client configuration if Firebase Console requires package-specific registration.
